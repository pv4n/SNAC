function [J, grad] = lrCostFunction(theta, X, y, lambda)
%LRCOSTFUNCTION Compute cost and gradient for logistic regression with 
%regularization
%   J = LRCOSTFUNCTION(theta, X, y, lambda) computes the cost of using
%   theta as the parameter for regularized logistic regression and the
%   gradient of the cost w.r.t. to the parameters. 

% Initialize some useful values
m = length(y); % number of training examples

J = 0;
grad = zeros(size(theta));

%       Each row of the resulting matrix will contain the value of the
%       prediction for that example. we make use of this to vectorize
%       the cost function and gradient computations. 


% First calculate the unregularized cost (J) and gradient (grad) for logistic regression
% (Taken straight from Coding Exercise 2 (costFunction.m))

h_of_x = sigmoid(X * theta);
J = 1 / m * sum( -1 * y' * log(h_of_x) - (1-y') * log(1 - h_of_x) );
grad = 1 / m * (X' * (h_of_x - y));  %'

% Next calculate the regularized cost (J) and gradient (grad) for logistic regression
% (Taken straight from Coding Exercise 2 (costFunctionReg.m))

% this effectively ignores "theta zero" in the following calculations
theta_zeroed_first = [0; theta(2:length(theta));];
J = J + lambda / (2 * m) * sum( theta_zeroed_first .^ 2 );
grad = grad .+ (lambda / m) * theta_zeroed_first;

% =============================================================

grad = grad(:);

end
