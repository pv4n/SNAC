% myplot2 will individually load log files and work with them 
% because otherwise there were discontinuities when concatinting all into one

